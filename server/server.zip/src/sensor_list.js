const sensor_list = {};

export { sensor_list };
